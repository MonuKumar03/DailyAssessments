const express = require('express');
const coursesRouter = require('./routes/courses');
const { errorHandler, notFoundHandler } = require('./middleware/errorHandler');
const apiLimiter = require('./middleware/rateLimiter');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json()); // Parse JSON bodies

// Apply rate limiting to all API routes
app.use('/api/v1/', apiLimiter);

// Routes
app.use('/api/v1/courses', coursesRouter);

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({ 
        status: 'OK', 
        message: 'Course Management API is running',
        timestamp: new Date().toISOString()
    });
});

// 404 handler for undefined routes
app.use(notFoundHandler);

// Centralized error handler
app.use(errorHandler);

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Course Management API v1 available at http://localhost:${PORT}/api/v1/courses`);
    console.log(`Health check at http://localhost:${PORT}/health`);
});

module.exports = app;