const { body, validationResult } = require('express-validator');

// Validation rules for course creation and update
const validateCourse = [
    body('name')
        .notEmpty()
        .withMessage('Course name is required')
        .isLength({ min: 3 })
        .withMessage('Course name must be at least 3 characters long'),
    
    body('duration')
        .notEmpty()
        .withMessage('Course duration is required')
        .isInt({ min: 1 })
        .withMessage('Duration must be a positive number (in hours)')
];

// Middleware to check validation results
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        const firstError = errors.array()[0];
        return res.status(400).json({ 
            error: firstError.msg 
        });
    }
    next();
};

module.exports = {
    validateCourse,
    handleValidationErrors
};