// Centralized error handling middleware
const errorHandler = (err, req, res, next) => {
    console.error('Error:', err);
    
    // Default error
    let error = { 
        error: 'Internal Server Error' 
    };
    let statusCode = 500;

    // Handle specific error types if needed
    if (err.name === 'ValidationError') {
        error.error = err.message;
        statusCode = 400;
    }

    res.status(statusCode).json(error);
};

// 404 handler for undefined routes
const notFoundHandler = (req, res) => {
    res.status(404).json({
        error: 'Endpoint not found'
    });
};

module.exports = {
    errorHandler,
    notFoundHandler
};