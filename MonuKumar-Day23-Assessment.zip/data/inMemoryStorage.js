// In-memory storage for courses
let courses = [];
let currentId = 1;

const getCourses = () => courses;

const getCourseById = (id) => courses.find(course => course.id === parseInt(id));

const addCourse = (courseData) => {
    const newCourse = {
        id: currentId++,
        name: courseData.name,
        duration: courseData.duration,
        createdAt: new Date().toISOString()
    };
    courses.push(newCourse);
    return newCourse;
};

const updateCourse = (id, courseData) => {
    const courseIndex = courses.findIndex(course => course.id === parseInt(id));
    if (courseIndex === -1) return null;
    
    courses[courseIndex] = {
        ...courses[courseIndex],
        name: courseData.name,
        duration: courseData.duration,
        updatedAt: new Date().toISOString()
    };
    
    return courses[courseIndex];
};

const deleteCourse = (id) => {
    const courseIndex = courses.findIndex(course => course.id === parseInt(id));
    if (courseIndex === -1) return false;
    
    courses.splice(courseIndex, 1);
    return true;
};

module.exports = {
    getCourses,
    getCourseById,
    addCourse,
    updateCourse,
    deleteCourse
};