const express = require('express');
const router = express.Router();
const {
    getCourses,
    getCourseById,
    addCourse,
    updateCourse,
    deleteCourse
} = require('../data/inMemoryStorage');
const { validateCourse, handleValidationErrors } = require('../middleware/validation');

// GET /api/v1/courses - Get all courses
router.get('/', (req, res) => {
    try {
        const courses = getCourses();
        res.json({
            success: true,
            data: courses,
            count: courses.length
        });
    } catch (error) {
        next(error);
    }
});

// GET /api/v1/courses/:id - Get course by ID
router.get('/:id', (req, res) => {
    try {
        const course = getCourseById(req.params.id);
        if (!course) {
            return res.status(404).json({
                error: 'Course not found'
            });
        }
        res.json({
            success: true,
            data: course
        });
    } catch (error) {
        next(error);
    }
});

// POST /api/v1/courses - Create new course
router.post('/', validateCourse, handleValidationErrors, (req, res) => {
    try {
        const newCourse = addCourse(req.body);
        res.status(201).json({
            success: true,
            message: 'Course created successfully',
            data: newCourse
        });
    } catch (error) {
        next(error);
    }
});

// PUT /api/v1/courses/:id - Update course
router.put('/:id', validateCourse, handleValidationErrors, (req, res) => {
    try {
        const updatedCourse = updateCourse(req.params.id, req.body);
        if (!updatedCourse) {
            return res.status(404).json({
                error: 'Course not found'
            });
        }
        res.json({
            success: true,
            message: 'Course updated successfully',
            data: updatedCourse
        });
    } catch (error) {
        next(error);
    }
});

// DELETE /api/v1/courses/:id - Delete course
router.delete('/:id', (req, res) => {
    try {
        const deleted = deleteCourse(req.params.id);
        if (!deleted) {
            return res.status(404).json({
                error: 'Course not found'
            });
        }
        res.json({
            success: true,
            message: 'Course deleted successfully'
        });
    } catch (error) {
        next(error);
    }
});

module.exports = router;