const express=require('express');
const bodyParser=require('body-parser');
const mongoose=require('mongoose');
const session=require('express-session');
const passport=require('passport');
const LocalStrategy=require('passport-local').Strategy;
const bcrypt=require('bcrypt');
const {body, validationResult}=require('express-validator');
require('dotenv').config();

const User=require('./models/User');
const app=express();

app.use(bodyParser.urlencoded({extended:true}));
app.set('view engine','ejs');

mongoose.connect(process.env.MONGO_URI).then(()=>console.log('DB connected'));

app.get("/", (req, res) => {
  res.send("Server is running ");
});

app.use(session({
  secret:process.env.SESSION_SECRET,
  resave:false,
  saveUninitialized:false
}));
app.use(passport.initialize());
app.use(passport.session());

// passport local strategy
passport.use(new LocalStrategy(async(username,password,done)=>{
  const user=await User.findOne({username});
  if(!user) return done(null,false);
  const match=await bcrypt.compare(password,user.password);
  if(!match) return done(null,false);
  return done(null,user);
}));

passport.serializeUser((user,done)=>done(null,user.id));
passport.deserializeUser(async(id,done)=>{
  const user=await User.findById(id);
  done(null,user);
});

// registration form
app.get('/register',(req,res)=>res.render('register'));

// validation + bcrypt + mongo save
app.post('/register',
[
 body('firstname').notEmpty(),
 body('lastname').notEmpty(),
 body('username').notEmpty(),
 body('password').isLength({min:5})
],
async(req,res)=>{
 const errs=validationResult(req);
 if(!errs.isEmpty())
   return res.send("Validation failed");

 const {firstname,lastname,username,password,role}=req.body;

 const hash=await bcrypt.hash(password,10);
 await User.create({firstname,lastname,username,password:hash,role});
 console.log("User saved:", username);

 res.send(`Registration successful for ${firstname} ${lastname}`);
});

// login form
app.get('/login',(req,res)=>res.render('login'));

app.post('/login', passport.authenticate('local',{failureRedirect:'/denied'}),(req,res)=>{
 res.redirect('/admin');
});

app.get('/denied',(req,res)=>res.send("Access Denied"));

function isAdmin(req,res,next){
 if(req.isAuthenticated() && req.user.role==="admin") return next();
 res.send("Access Denied");
}

app.get('/admin', isAdmin, (req,res)=>res.send("Welcome, Admin!"));

app.listen(3000,()=>console.log("Running on 3000"));
