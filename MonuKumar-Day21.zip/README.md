# 📘 SkillSphere LMS – Day 21 (Middleware & Templates)

A Node.js + Express project demonstrating:

- Lightweight & modular middleware
- Custom logging + Morgan production logging
- Template rendering using EJS
- JSON body parsing & form handling
- Dynamic routes & data validation
- Clean folder architecture following best practices

---

## 🚀 Features

### ✅ 1. Global Logging Middleware (Custom + Morgan)
- **Custom logger** for readable logs
- **Morgan** (combined mode) for production-grade logging
- Both run together as per your selection (Option C)

### ✅ 2. Body Parsing Middleware
- `express.json()` – parses JSON bodies
- `express.urlencoded({ extended: true })` – parses form data

### ✅ 3. Course Routes
- `GET /courses` → Renders all courses using EJS template
- `GET /courses/:id` → Returns a single course (validated ID)
- `POST /courses` → Adds a new course and updates `courses.json`

### ✅ 4. User Routes
- `POST /users` → Creates a new user
- `GET /users` → Returns all users in memory

### ✅ 5. EJS Template Rendering
- All templates stored in the `views/` folder
- No business logic inside templates
- Clean markup for easy maintenance

---

## 📁 Project Structure
skill-sphere-lms-day21-best/
├── index.js
├── package.json
├── .gitignore
├── routes/
│ ├── courses.js
│ └── users.js
├── middleware/
│ ├── logger.js
│ └── validateCourseId.js
├── data/
│ └── courses.json
├── views/
│ └── courses.ejs
└── README.md


---

## ⚙️ Installation & Setup

1. **Install dependencies**
   ```bash
   npm install
2. **Start the server**
   ```bash
   npm start